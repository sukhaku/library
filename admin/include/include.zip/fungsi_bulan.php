<?php
switch ($bulan) {
	case '01':
	$indo="Januari";
	break;
	
	case '2':
	$indo="Februari";
	break;
	case '3':
	$indo="Maret";
	break;
	case '4':
	$indo="April";
	break;
	case '5':
	$indo="Mei";
	break;
	case '6':
	$indo="Juni";
	break;
	case '7':
	$indo="Juli";
	break;
	case '8':
	$indo="Agustus";
	break;
	case '9':
	$indo="September";
	break;
	case '10':
	$indo="Oktober";
	break;
	case '11':
	$indo="November";
	break;
	case '12':
	$indo="Desember";
	break;
	
	default:
		# code...
		break;
}

?>